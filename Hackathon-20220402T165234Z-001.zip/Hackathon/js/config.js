firebase.initializeApp({
  apiKey: "AIzaSyCWU1zIRCIQIDs1wef5FwAdKdSm1yPEwEs",
  authDomain: "be-luro-9488e.firebaseapp.com",
  projectId: "be-luro-9488e",
  storageBucket: "be-luro-9488e.appspot.com",
  messagingSenderId: "124555602691",
  appId: "1:124555602691:web:4bc9bef6a20a9743c55736",
  measurementId: "G-737BQJGMZR"
});

const auth = firebase.auth();